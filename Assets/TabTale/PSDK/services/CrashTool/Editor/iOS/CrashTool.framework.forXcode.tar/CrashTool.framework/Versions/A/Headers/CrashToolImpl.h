//
//  CrashToolImpl.h
//  CrashTool
//
//  Created by Ariel Vardy on 2/9/16.
//  Copyright © 2016 Ariel Vardy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PublishingSDKCore/PublishingSDKCore.h>
#import <HockeySDK/HockeySDK.h>

@interface PSDKCrashToolImpl : NSObject <PSDKCrashTool, PSDKConfigurationFetcherDelegate, BITHockeyManagerDelegate>

- (id) initWithDic:(NSString*) key;

@end

