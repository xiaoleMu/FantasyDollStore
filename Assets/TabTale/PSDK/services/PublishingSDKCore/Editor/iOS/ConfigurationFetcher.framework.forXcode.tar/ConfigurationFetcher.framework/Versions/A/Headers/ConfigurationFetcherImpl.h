//
//  ConfigurationFetcherImpl.h
//  ConfigurationFetcher
//
//  Created by Gal Briner on 9/8/14.
//  Copyright (c) 2014 Tabtale. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PublishingSDKCore/PublishingSDKCore.h>

@interface PSDKConfigurationFetcherImpl : NSObject<PSDKConfigurationFetcher, PSDKAppLifeCycleDelegate, PSDKLanguage>

- (id) initWithParams:(PSDKAppLifeCycleMgr*)appLifeCycleMgr
             language:(NSString*)language
                store:(NSString*)store
           sdkVersion:(NSString*)sdkVersion
           gameEngine:(NSString*)gameEngine
          orientation:(NSString*)orientation
               config:(NSDictionary*)config
             delegate:(id<PSDKConfigurationDelegate>)delegate
          localConfig:(NSDictionary*)localConfig;

@end
