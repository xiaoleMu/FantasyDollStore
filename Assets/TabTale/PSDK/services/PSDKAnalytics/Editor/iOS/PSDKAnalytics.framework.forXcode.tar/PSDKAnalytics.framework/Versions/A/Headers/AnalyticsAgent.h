//
//  PSDKAnalyticsAgent.h
//  PSDKAnalytics
//
//  Created by Ariel Vardy on 8/31/15.
//  Copyright (c) 2015 Tabtale. All rights reserved.
//

#ifndef PSDKAnalytics_AnalyticsAgent_h
#define PSDKAnalytics_AnalyticsAgent_h

#import <PublishingSDKCore/PublishingSDKCore.h>
#import "StorageMgr.h"

static const int TT_AGENT_COUNT        = 3;
static const int TT_ANALYTICS_INDEX    = 0;
static const int TT_FLURRY_INDEX       = 1;
static const int TT_DELTA_DNA_INDEX    = 2;

@interface PSDKAnalyticsAgent : NSObject  <PSDKConfigurationFetcherDelegate, PSDKLanguage, PSDKAppLifeCycleDelegate>

@property (nonatomic) int index;
@property (nonatomic, strong) id<PSDKAnalyticsDelegate> delegate;

@property (nonatomic, strong) PSDKConfigurationFetcherHelper* configurationFetcher;
@property (nonatomic, strong) id<PSDKStorageMgr> storageMgr;
@property (nonatomic) BOOL enabled;
@property (nonatomic) BOOL storeEventsMode;
@property (nonatomic, strong) NSString* key;
@property (nonatomic, strong) NSString* previousKey;

- (id) initWithDic:(NSDictionary*)config
        andStorage:(id<PSDKStorageMgr>)storageMgr
          delegate:(id<PSDKAnalyticsDelegate>)delegate
      appLifeCycle:(PSDKAppLifeCycleMgr*)applifecycleMgr;
- (void) logEvent:(NSString*)eventName params:(NSMutableDictionary*) params timed:(BOOL) timed internal:(BOOL)internal;
- (void) endTimedEvent:(NSString*)eventName params:(NSMutableDictionary*) params;
- (NSString*) getCustomerUserID;
- (NSString *)getFlurryKey;
- (BOOL) requestEngagement:(NSString*)decisionPoint params:(NSDictionary*)params;
- (NSString*) getServiceParamKey;
- (void) exitStoredMode;
- (void) enterStoredMode;
- (void) validateParams:(NSMutableDictionary*)params eventName:(NSString*)eventName;
- (NSMutableDictionary*) addParams:(NSMutableDictionary*)dic eventName:(NSString*)eventName;
- (void) reportAttributionEvent:(NSDictionary*)data;
- (void) addExtras: (NSDictionary*)givenExtras;
- (void) removeExtras: (NSArray *)keys;
- (void) forgetUser;

@end

#endif
