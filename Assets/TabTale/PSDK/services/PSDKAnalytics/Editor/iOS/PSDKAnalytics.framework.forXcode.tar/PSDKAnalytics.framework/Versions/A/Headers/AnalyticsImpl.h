//
//  PSDKAnalyticsImpl.h
//  PSDKAnalytics
//
//  Created by Ariel Vardy on 8/30/15.
//  Copyright (c) 2015 Tabtale. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PublishingSDKCore/PublishingSDKCore.h>

@interface PSDKTimedEventData : NSObject

- (id) initWithTime:(NSDate*)date param:(NSDictionary*)dic targets:(AnalyticsType)targets;

@end

@interface PSDKAnalyticsImpl : NSObject<PSDKAnalyticsExt, PSDKLanguage, PSDKAppLifeCycleDelegate>

@property (nonatomic, strong) NSMutableArray* agents;

- (id) initWithDic:(NSDictionary*)config
          delegate:(id<PSDKAnalyticsDelegate>)delegate
      appLifeCycle:(PSDKAppLifeCycleMgr*)applifecycleMgr;
- (void) logEvent:(NSString*) eventName params:(NSDictionary*) params timed:(BOOL) timed;
- (void) endTimedEvent:(NSString*) eventName params:(NSDictionary*) params;
- (void) addExtras: (NSDictionary*)params;
- (void) removeExtras: (NSArray *)keys;
@end
