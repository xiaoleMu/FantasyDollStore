//
//  PSDKSingularImpl.h
//  PSDKSingular
//
//  Created by Ariel Vardy on 24/09/2017.
//  Copyright © 2017 Ariel Vardy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PublishingSDKCore/PublishingSDKCore.h>

@interface PSDKSingularImpl : NSObject <PSDKSingular, PSDKConfigurationFetcherDelegate, PSDKAppLifeCycleDelegate>

- (id) initWithDic:(NSDictionary*)config
      appLifeCycle:(PSDKAppLifeCycleMgr*)applifecycleMgr;

@end
