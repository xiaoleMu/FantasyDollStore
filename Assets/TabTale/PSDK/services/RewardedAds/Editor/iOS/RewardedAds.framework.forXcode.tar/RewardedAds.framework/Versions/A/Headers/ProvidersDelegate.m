//
//  PSDKAbstructDelegate.m
//  RewardedAds
//
//  Created by Ariel Vardy on 4/6/15.
//  Copyright (c) 2015 Liran Aknin. All rights reserved.
//

#import "ProvidersDelegate.h"

@implementation PSDKProvidersDelegate

@end
