//
//  TTVungleSDKDelegate.h
//  TTVungleSDKDelegate
//
//  Created by Ariel Vardy on 20/03/2018.
//  Copyright © 2018 Ariel Vardy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VungleSDK/VungleSDK.h>

@protocol TTVungleSDKDelegate <NSObject>
@optional

- (void)vungleAdPlayabilityUpdate:(BOOL)isAdPlayable placementID:(nullable NSString *)placementID;
- (void)vungleWillShowAdForPlacementID:(nullable NSString *)placementID;
- (void)vungleWillCloseAdWithViewInfo:(nonnull VungleViewInfo *)info placementID:(nonnull NSString *)placementID;
- (void)vungleSDKDidInitialize;
- (void)vungleSDKFailedToInitializeWithError:(nonnull NSError *)error;

@end

@interface TTVungleSDKWrapper : NSObject <VungleSDKDelegate>

+ (nonnull instancetype)sharedInstance;
- (void) addDeleagate:(nonnull id<TTVungleSDKDelegate>) delegate andPlacement:(nonnull NSString*) placement andKey:(nonnull NSString*)key;
- (void) start;
- (BOOL) playAd:(nullable UIViewController *)controller options:(nullable NSDictionary *)options placementID:(nullable NSString *)placementID error:( NSError *__autoreleasing _Nullable *_Nullable)error;
- (BOOL) loadPlacementWithID:(nullable NSString *)placementID error:(NSError *__autoreleasing _Nullable *_Nullable)error;
- (BOOL)isAdCachedForPlacementID:(nonnull NSString *)placementID;

@end
